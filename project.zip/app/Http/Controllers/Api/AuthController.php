<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class AuthController
{
    public function login(Request $request)
    {
        // 1. Validácia vstupu
        $credentials = $request->validate([
            'email' => 'required|email',
            'password' => 'required|string',
        ]);

        // 2. Pokus o prihlásenie
        if (!Auth::attempt($credentials)) {
            return response()->json([
                'message' => 'Neplatné prihlasovacie údaje.'
            ], 401);
        }

        $user = $request->user();

        $token = $user->createToken('api-token')->plainTextToken;

        return response()->json([
            'user' => $user,
            'token' => $token,
        ]);
    }

    public function me(Request $request)
    {
        return response()->json($request->user());
    }

    public function changePassword(Request $request)
    {
        $request->validate([
            'current_password' => ['required'],
            'new_password' => ['required', 'min:6', 'confirmed'],
        ]);

        $user = $request->user();

        // kontrola starého hesla
        if (!Hash::check($request->current_password, $user->password)) {
            return response()->json([
                'message' => 'Nesprávne aktuálne heslo.'
            ], 400);
        }

        // uloženie nového hesla
        $user->password = $request->new_password; // u Vás sa hashne automaticky
        $user->save();

        return response()->json([
            'message' => 'Heslo bolo zmenené.'
        ]);
    }

    public function logout(Request $request)
    {
        $request->user()->currentAccessToken()->delete();

        return response()->json([
            'message' => 'Odhlásenie úspešné.'
        ]);
    }
}
