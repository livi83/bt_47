<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class PostResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'title' => $this->title,
            'slug' => $this->slug,
            'body' => $this->content, // Premenovali sme content na body
            'image' => $this->image_path,
            'published_date' => $this->published_at?->format('d.m.Y'), // Formát dátumu
            'author' => $this->author->name, // Vytiahneme len meno autora
            'categories' => $this->categories->pluck('name'), // Len názvy kategórií
        ];
    }
}
